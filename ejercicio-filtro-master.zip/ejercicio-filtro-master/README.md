# ejercicio-filtro

* Maquetar una web siguiendo la imagen de ejemplo

![Image description](https://github.com/malerey/ejercicio-filtro/blob/master/Screen%20Shot%202020-02-07%20at%2019.09.04.png)

* El objeto ya esta creado en el archivo .js 

* Esta *prohibido* usar for. Para recorrer el objeto, debemos usar forEach, map, filter, o cualquier otro método de arrays. Para recorrer colecciones de HTML (por ejemplo, las que nos devuelve document.getElementsByClassName) si necesitaremos for.  

* El filtro debe funcionar tanto cuando el usuario aprieta enter, como cuando aprieta el boton de "filtrar". 

* El filtro debe funcionar por color o por tipo, no es necesario que funcione con ambos a la vez. 

* Si el campo está vacío, se deben devolver todos los productos. 

* Si ningun producto cumple la busqueda (por ejemplo "verde") no se debe mostrar ningun producto. 

* No pasen mucho tiempo en el maquetado, dediquense a javascript. 

* Al final de la clase, subirlo a github y mandarme link O LAS PERSEGUIRE UNA POR UNA PARA QUE LO HAGAN

